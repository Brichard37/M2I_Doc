import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatage'
})
export class FormatagePipe implements PipeTransform {

  transform(value: number, args?: any): string {
    return "$$$" + value + "$$$";
  }

}
