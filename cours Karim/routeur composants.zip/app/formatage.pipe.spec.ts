import { FormatagePipe } from './formatage.pipe';

describe('FormatagePipe', () => {
  it('create an instance', () => {
    const pipe = new FormatagePipe();
    expect(pipe).toBeTruthy();
  });
});
