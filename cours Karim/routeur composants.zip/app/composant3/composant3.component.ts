import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-composant3',
  templateUrl: './composant3.component.html',
  styleUrls: ['./composant3.component.css']
})
export class Composant3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
