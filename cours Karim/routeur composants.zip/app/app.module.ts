import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormatagePipe } from './formatage.pipe';
import { Composant2Component } from './composant2/composant2.component';
import { Composant3Component } from './composant3/composant3.component';
//import { CalculService } from './calcul.service';

@NgModule({
  declarations: [
    AppComponent,
    FormatagePipe,
    Composant2Component,
    Composant3Component,
	//CalculService

  ],
  imports: [
    BrowserModule,
	HttpClientModule,
	AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }	
