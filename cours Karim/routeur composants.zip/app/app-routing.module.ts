import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { Composant2Component } from './composant2/composant2.component';
import { Composant3Component } from './composant3/composant3.component';

const routes: Routes = [
 { path: 'composant2', component: Composant2Component},
 { path: 'composant3', component: Composant3Component},
 { path: 'home', component: AppComponent},
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
