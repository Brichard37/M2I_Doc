import { Component } from '@angular/core';
import { Pipe, PipeTransform } from '@angular/core';	
import { Injectable } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { CalculService } from './calcul.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  titre = 'le compteur';
  compteur : number = 0;
  data: string = "Coucou"
  url : string ='http://localhost:8080/angular-servlet/compter';
  constructor(public http: HttpClient, c : CalculService){
	console.log("constructor")
	console.log(c.somme(10,20))
  }
  envoyer()
  {
	valider(data);
  }
  /*
  envoyer()
  {
  	this.http.get(this.url).subscribe(response => {
		console.log(response)
    });
  }*/
}
