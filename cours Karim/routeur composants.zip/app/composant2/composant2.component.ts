import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-composant2',
  templateUrl: './composant2.component.html',
  styleUrls: ['./composant2.component.css']
})
export class Composant2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
