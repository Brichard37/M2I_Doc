import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class CalculService {

  constructor() { }
  
  public somme(i : number, j: number)
  {
	return i + j
  }
  
}
